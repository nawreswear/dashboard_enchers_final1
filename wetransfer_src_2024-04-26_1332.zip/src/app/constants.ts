export const API_URL = 'https://store-21c6.onrender.com/api';
// export const API_URL = 'http://localhost:8080/api';
