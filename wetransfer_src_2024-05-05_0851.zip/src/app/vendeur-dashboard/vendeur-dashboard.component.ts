import { Component } from '@angular/core';

@Component({
  selector: 'app-vendeur-dashboard',
  templateUrl: './vendeur-dashboard.component.html',
  styleUrls: ['./vendeur-dashboard.component.css']
})
export class VendeurDashboardComponent {

}
